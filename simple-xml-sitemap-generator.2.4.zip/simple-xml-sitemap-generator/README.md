# simple xml sitemap generator

## Description
XML Sitemap creates an XML for use with Google and Yahoo (and Yes! Bing too)
Just install it to your wordpress installation and let the plugin do his job.

